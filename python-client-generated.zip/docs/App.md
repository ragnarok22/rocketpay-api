# App

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Name of current app | 
**fee_percents** | **float** | Fee for incoming transactions | 
**balances** | [**list[AppBalance]**](AppBalance.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

