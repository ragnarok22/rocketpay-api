# PaginationDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**total** | **float** | Total times | 
**limit** | **float** |  | [default to 100]
**offset** | **float** |  | [default to 100]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

