# SubscriptionResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **float** | Resource ID | 
**type** | **str** | Resource type | 
**resource_id** | **str** | Resource TG ID | 
**name** | **str** | Resource TG title | 
**linked_chat** | **str** | Resource TG ID | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

