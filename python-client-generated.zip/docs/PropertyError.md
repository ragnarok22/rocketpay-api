# PropertyError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**_property** | **str** | name of input field that cannot be processed | 
**error** | **str** | text explaining what exactly wrong | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

