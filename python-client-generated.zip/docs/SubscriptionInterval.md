# SubscriptionInterval

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**interval** | **str** | Interval for subscription | 
**amount** | **float** | Cost subscription for current interval in currency | 
**status** | **str** | Status for subscription | 
**code** | **str** | Interval code | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

