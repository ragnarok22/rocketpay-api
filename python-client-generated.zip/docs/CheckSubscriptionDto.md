# CheckSubscriptionDto

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**user_id** | **float** | TG User id | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

